// This component is obsolete and has been replaced by ImageManager.tsx
import React from 'react';

const ImageUpload: React.FC = () => {
    return null;
}

export default ImageUpload;