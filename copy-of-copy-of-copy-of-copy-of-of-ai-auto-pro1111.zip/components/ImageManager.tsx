// This component is obsolete and has been replaced by the contextual
// evidence gathering UI directly within InspectionForm.tsx
import React from 'react';

const ImageManager: React.FC = () => {
    return null;
}

export default ImageManager;
