// This component is no longer used and has been removed from the application flow.
// The app now loads directly into the main dashboard for a streamlined experience.
import React from 'react';
const LoginScreen: React.FC = () => null;
export default LoginScreen;
